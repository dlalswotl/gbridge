package javabook.ch5;

public enum PayType {
	CARD,
	CASH
}
