package javabook.ch5;

public interface IShop {
	void setTitle(String title);
	void genUser();
	void genProduct();
	void start();
}
